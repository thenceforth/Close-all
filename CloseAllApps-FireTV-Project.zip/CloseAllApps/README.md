# Close All Apps — Fire TV Cube

A Fire TV launcher app designed for a one-click "Close All Apps" action.

## Important

A normal Android APK cannot call `am force-stop` directly because that command requires shell/system privileges. This project therefore uses an AccessibilityService to open each user-installed app's App Info page and press the normal Fire OS/Android **Force stop** control.

The app deliberately skips:
- itself (`com.mehmet.closeallapps`)
- `dev.vodik7.atvtoolsserver`
- system apps
- updated system apps

## One-time setup

1. Install the APK on the Fire TV Cube.
2. Open **Close All Apps**.
3. Select **ENABLE ACCESSIBILITY**.
4. Enable the Close All Apps accessibility service.
5. Return to the app.
6. Press **CLOSE ALL APPS**.

After that, opening the app from the Fire TV home screen and pressing the main button starts the sequence.

## Optional ADB enablement

If Fire OS permits shell changes to the accessibility setting, the service can also be enabled from ADB with:

    settings put secure enabled_accessibility_services com.mehmet.closeallapps/com.mehmet.closeallapps.CloseAllAccessibilityService
    settings put secure accessibility_enabled 1

The exact accessibility UI on Fire OS can differ by version, so the Settings UI method is the recommended setup.

## Build

Open this folder in Android Studio and let Gradle sync. Build > Build Bundle(s) / APK(s) > Build APK(s).

Package: `com.mehmet.closeallapps`
Name: `Close All Apps`
Target: Android/Fire TV, API 28+
