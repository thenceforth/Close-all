package com.mehmet.closeallapps;

import android.accessibilityservice.AccessibilityService;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Fire TV friendly fallback: uses Accessibility to press the normal Android/Fire OS
 * "Force stop" control in each user-installed app's App Info screen.
 * This avoids requiring the signature-only FORCE_STOP_PACKAGES permission.
 */
public class CloseAllAccessibilityService extends AccessibilityService {
    private static CloseAllAccessibilityService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<String> queue = new ArrayList<>();
    private int index = 0;
    private boolean running = false;
    private long lastAction = 0;

    @Override public void onServiceConnected() { instance = this; }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }

    public static void startClosing() {
        if (instance != null) instance.begin();
    }

    private void begin() {
        if (running) return;
        queue.clear();
        index = 0;
        PackageManager pm = getPackageManager();
        String own = getPackageName();
        try {
            List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
            for (ApplicationInfo ai : apps) {
                if (ai.packageName.equals(own)) continue;
                if (ai.packageName.equals("dev.vodik7.atvtoolsserver")) continue;
                if ((ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
                if ((ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0) continue;
                queue.add(ai.packageName);
            }
        } catch (Exception ignored) { }
        running = true;
        nextPackage();
    }

    private void nextPackage() {
        if (!running) return;
        if (index >= queue.size()) {
            running = false;
            try { performGlobalAction(GLOBAL_ACTION_HOME); } catch (Exception ignored) { }
            return;
        }
        String pkg = queue.get(index++);
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.parse("package:" + pkg));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
            handler.postDelayed(() -> scanForForceStop(0), 700);
        } catch (Exception e) {
            handler.postDelayed(this::nextPackage, 200);
        }
    }

    private void scanForForceStop(int attempt) {
        if (!running) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) {
            AccessibilityNodeInfo node = findForceStop(root);
            if (node != null && node.isEnabled()) {
                try {
                    lastAction = System.currentTimeMillis();
                    node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    handler.postDelayed(() -> {
                        try { performGlobalAction(GLOBAL_ACTION_BACK); } catch (Exception ignored) { }
                        handler.postDelayed(this::nextPackage, 350);
                    }, 450);
                    return;
                } catch (Exception ignored) { }
            }
        }
        if (attempt < 15) handler.postDelayed(() -> scanForForceStop(attempt + 1), 250);
        else {
            try { performGlobalAction(GLOBAL_ACTION_BACK); } catch (Exception ignored) { }
            handler.postDelayed(this::nextPackage, 300);
        }
    }

    private AccessibilityNodeInfo findForceStop(AccessibilityNodeInfo root) {
        ArrayList<AccessibilityNodeInfo> all = new ArrayList<>();
        collect(root, all);
        for (AccessibilityNodeInfo n : all) {
            CharSequence t = n.getText();
            CharSequence d = n.getContentDescription();
            String s = ((t == null ? "" : t.toString()) + " " + (d == null ? "" : d.toString())).toLowerCase(Locale.ROOT);
            if (s.contains("force stop") || s.contains("force-stop") || s.contains("zwangsbeenden") ||
                    s.contains("beenden erzwingen") || s.contains("stop erzwingen")) {
                if (n.isClickable() && n.isEnabled()) return n;
                AccessibilityNodeInfo p = n.getParent();
                if (p != null && p.isClickable() && p.isEnabled()) return p;
            }
        }
        return null;
    }

    private void collect(AccessibilityNodeInfo n, ArrayList<AccessibilityNodeInfo> out) {
        out.add(n);
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c != null) collect(c, out);
        }
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!running) return;
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                event.getEventType() == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            if (System.currentTimeMillis() - lastAction > 600) {
                handler.postDelayed(() -> scanForForceStop(0), 100);
            }
        }
    }
}
