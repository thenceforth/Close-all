package com.mehmet.closeallapps;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends android.app.Activity {
    private TextView status;
    private Button closeButton;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(80, 50, 80, 50);
        root.setBackgroundColor(0xFF000000);

        TextView title = new TextView(this);
        title.setText("CLOSE ALL APPS");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(34);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        status = new TextView(this);
        status.setTextColor(0xFFFFFFFF);
        status.setTextSize(18);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 30, 0, 30);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        closeButton = new Button(this);
        closeButton.setText("CLOSE ALL APPS");
        closeButton.setTextSize(24);
        closeButton.setOnClickListener(v -> {
            if (!isAccessibilityEnabled()) {
                openAccessibilitySettings();
            } else {
                CloseAllAccessibilityService.startClosing();
                status.setText("Closing user apps…");
            }
        });
        root.addView(closeButton, new LinearLayout.LayoutParams(-1, 120));

        Button settings = new Button(this);
        settings.setText("ENABLE ACCESSIBILITY");
        settings.setOnClickListener(v -> openAccessibilitySettings());
        root.addView(settings, new LinearLayout.LayoutParams(-1, 90));

        setContentView(root);
        updateStatus();
    }

    @Override protected void onResume() {
        super.onResume();
        updateStatus();
    }

    private void updateStatus() {
        if (status == null) return;
        status.setText(isAccessibilityEnabled()
                ? "Ready — press CLOSE ALL APPS"
                : "Accessibility permission is required once.");
    }

    private void openAccessibilitySettings() {
        try {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private boolean isAccessibilityEnabled() {
        android.view.accessibility.AccessibilityManager am =
                (android.view.accessibility.AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
        List<AccessibilityServiceInfo> list = am.getEnabledAccessibilityServiceList(
                AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        String me = new ComponentName(this, CloseAllAccessibilityService.class).flattenToString();
        for (AccessibilityServiceInfo info : list) {
            if (info.getResolveInfo() != null && info.getResolveInfo().serviceInfo != null) {
                ComponentName cn = new ComponentName(info.getResolveInfo().serviceInfo.packageName,
                        info.getResolveInfo().serviceInfo.name);
                if (me.equals(cn.flattenToString())) return true;
            }
        }
        return false;
    }
}
